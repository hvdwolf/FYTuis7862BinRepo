#!/system/bin/sh

cp -v /storage/sdcard1/config.txt /oem/app

chmod 644  /oem/app/config.txt

##########################################
# When the timer appears asking you to
# remove the flash memory, you can do so
##########################################
