#!/system/bin/sh

# Harry van der Wolf, V1.1, 14-10-2023
# Backup script for uis7862, uis8518 and sc9853i

rm -rf /storage/sdcard1/BACKUP
mkdir -p /storage/sdcard1/BACKUP

echo "twipe_data" > /storage/sdcard1/BACKUP/updatecfg.txt
cp /storage/sdcard1/lsec6316update /storage/sdcard1/BACKUP
cp /oem/app/config.txt /storage/sdcard1/BACKUP

chmod +x /storage/sdcard1/zip-arm
##############################################################################
# Create the AllAppUpdate,bin
# using /storage/sdcard1/zip-arm -r -0 --password 048a02243bb74474b25233bda3cd02f8 /storage/sdcard1/BACKUP/AllAppUpdate.bin /oem/* > /storage/sdcard1/BACKUP/AllAppUpdate.bin.log 2>&1
# We echo all output to the log to detect errors
##############################################################################
/storage/sdcard1/zip-arm -r -v -y -0 --password 048a02243bb74474b25233bda3cd02f8 /storage/sdcard1/BACKUP/AllAppUpdate.bin /oem/* > /storage/sdcard1/BACKUP/AllAppUpdate.bin.log 2>&1

##############################################################################
# You will find on your usb-stick inside the folder BACKUP
# four files:
#    AllAppUpdate.bin
#    config.txt
#    updatecfg.txt
#    lsec6316update
#
# and AllAppUpdate.bin.log
#
# If you copy these four files with a 6316_1.zip
# to a clean USB-disk, you can always
# restore your sc9863a (uis8581a) unit.
