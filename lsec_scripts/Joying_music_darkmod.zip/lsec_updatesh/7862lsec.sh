#!/system/bin/sh
#

# First copy locally as we can't do a rename/move on the OEM location
cp /storage/sdcard1/190043001_com.syu.music.apk /storage/sdcard1/190000008_com.syu.music.apk

rm -rf /data/dalvik-cache/profiles/com.syu.music
rm -rf /oem/app/190000008_com.syu.music
mkdir -p /oem/app/190000008_com.syu.music
cp -rf  /storage/sdcard1/190000008_com.syu.music.apk /oem/app/190000008_com.syu.music/
chmod 0755 /oem/app/190000008_com.syu.music
chown -R 0.0 /oem/app/190000008_com.syu.music/190000008_com.syu.music.apk
chmod 0644 /oem/app/190000008_com.syu.music/190000008_com.syu.music.apk

# Remove locally copied version
rm -rf /storage/sdcard1/190000008_com.syu.music.apk