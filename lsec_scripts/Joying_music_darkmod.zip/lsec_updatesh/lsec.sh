#!/system/bin/sh
#

rm -rf /cache/mplayer

mkdir 755 /cache/mplayer

cp -vr /storage/sdcard1/mplayer/mplayer_remover.sh /cache/mplayer/mplayer_remover.sh

chmod -R 755 /cache/mplayer

cd /cache/mplayer

########################################
# Removing the current
# music player
########################################

/cache/mplayer/mplayer_remover.sh

rm -rf /cache/mplayer

mkdir -p /oem/app/190043001_com.syu.music
cp -rf  /storage/sdcard1/190043001_com.syu.music.apk /oem/app/190043001_com.syu.music/
chmod 0755 /oem/app/190043001_com.syu.music
chown -R 0.0 /oem/app/190043001_com.syu.music/190043001_com.syu.music.apk
chmod 0644 /oem/app/190043001_com.syu.music/190043001_com.syu.music.apk

########################################
# When the timer appears asking you to
# remove the flash memory, you can do so
########################################
