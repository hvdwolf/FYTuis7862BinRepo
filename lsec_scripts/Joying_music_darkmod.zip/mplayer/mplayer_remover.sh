#!/system/bin/sh
# HvdW 20220131 V0.1

# POSSIBLE Music apks
JOYING="/oem/app/190043001_com.syu.music/190043001_com.syu.music.apk"
GENERAL="/oem/app/190000010_com.syu.music/190000010_com.syu.music.apk"


#### radio functions ####
joying() {
   cp /oem/app/190043001_com.syu.music/190043001_com.syu.music.apk /storage/sdcard1/BACKUP_MUSIC_APK/
   mv /oem/app/190043001_com.syu.music/190043001_com.syu.music.apk /oem/app/190043001_com.syu.music/190043001_com.syu.music.apk.bak
}

general() {
   cp /oem/app/190000010_com.syu.music/190000010_com.syu.music.apk /storage/sdcard1/BACKUP_MUSIC_APK
   mv /oem/app/190000010_com.syu.music/190000010_com.syu.music.apk 190000010_com.syu.music/190000010_com.syu.music.apk.bak
}

mkdir -p /storage/sdcard1/BACKUP_MUSIC_APK
rm -rf /data/dalvik-cache/profiles/com.syu.music


# Check which radio apk is installed
[ -e "$GENERAL" ] || general
[ -e "$JOYING" ] || joying


