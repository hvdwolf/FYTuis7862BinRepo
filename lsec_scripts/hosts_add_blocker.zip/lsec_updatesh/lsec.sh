#!/system/bin/sh
#

#####################################################
#
# This hosts file is copied from:
# https://winhelp2002.mvps.org/hosts.htm
# modification: changed all entries back from 0.0.0.0
# to 127.0.0.1.
#
#####################################################


mount -o remount,rw /system
cp /storage/sdcard1/lsec_updatesh/hosts /system/etc/hosts
chmod 644 /system/etc/hosts

#####################################################
#
#  After the reboot you will get a green message with:
#  "Update finished! Remove the flash memory (x)",
#  with an increasing seconds counter.
#  Wait a 3-5 seconds before really unplugging 
#  the usb-stick.
#
#  After the reboot your system should be almost
#  fully protected against adds in programs.
#
#####################################################


