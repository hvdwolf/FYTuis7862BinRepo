What does this script do.

Inside the fyt.prop you will find the reseller id as ro.build.fytmanufacturer="some id"

If you flashed an AllAppUpdate.bin with a wrong id, you will get the yellow bar with the
big red letters "ui and mcu does not match" (which is incorrect English, but that aside).
If you still know the correct id for your firmware, you can upgrade the fyt.prop with
these scripts inside folder lsec_update.

= If you have a sc9853i, you need to update the lsec.sh script.
= If you have a uis7862 (ums512), you need to update the 7862lsec.sh script
= If you have a uis8581a (sc9863a), you need to update the 8581lsec.sh script

If you are a windows user do NOT use windows notepad to update the script. Use a proper editor like Notepad++.

It is ONLY this line:
sed -i "25i ro\.build\.fytmanufacturer=999" /oem/app/fyt.prop

The only thing you need to change is the number 999 to the id of your unit. Nothing else.
Again: ONLY change 999 to the correct id.

Most common ids:
If you have a Joying it is 43
If you have a Mekede it can be 116 or 1
A lot of units have 1
IJing has (mostly) 31.

