#!/system/bin/sh
#

# Updating fyt.prop

# First we will delete the line with the fytmanufacturer
sed -i '/^ro\.build\.fytmanufacturer/d' /oem/app/fyt.prop

# Now we need to insert the correct reseller id
# into the fyt.prop
# In the below line you see 999 as the reseller id
# ONLY that number need to be changed to the correct id
# Do not change anything else
# Do not use windows notepad to edit this file

sed -i "25i ro\.build\.fytmanufacturer=999" /oem/app/fyt.prop


##########################################
# When the timer appears asking you to
# remove the flash memory, you can do so
##########################################