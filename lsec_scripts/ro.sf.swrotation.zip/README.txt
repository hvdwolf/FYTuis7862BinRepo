
Probably you are here because you did not read the Forums well enough and flashed a firmware to your FYT with
a different screen orientation.

What does this script do?
It can set the correct orientation for your screen. This is set by a property called "ro.sf.swrotation=xy", 
where xy is a value of 0, 90, 180 or 270 . Use the value from YOUR firmware in the config.txt.
You will find a config.txt with this script that contains the default value for most units being ro.sf.swrotation=90

In case you have no longer your original firmware you simply need to experiment with the above values until you have the right one.
