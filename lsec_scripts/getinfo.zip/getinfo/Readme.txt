== How to use ==

Simply copy the files to a clean USB-stick and put it in your unit.
It will start the "flash" process on your unit, but in this case only
a script qill start collection info from your unit.

After the script has run you get a green message that the "flash"
process was successful. This green message has a counter.
Wait 5 seconds (or more) before removing the USB-stick.

== Afterwards on the USB stick ==
On the USB-stick you will find a folder "FYTget_info" containing
a lot of files.
You will also find a file called "FYTget_info.tgz", which is a
compressed "gnu-zipped" tar file. Any linux/MacOS filemanager can
open it and any zip program on windows can also open it.