#!/system/bin/sh
#

rm -rf /data/dalvik-cache/profiles/com.syu.air

mv /oem/app/190000000_com.syu.air/190000000_com.syu.air.apk /oem/app/190000000_com.syu.air/190000000_com.syu.air.apk.org

