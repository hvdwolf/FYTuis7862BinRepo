binary		=> unit			=> script

lsec6315update	=> uis7862 (ums512) 	=> 7862lsec.sh
lsec6316update	=> sc9863a (uis8581a)	=> 8581lsec.sh
lsec6521update  => sc9853i		=> lsec.sh

The unit will automatically select the correct binary and accompanying script.
The binaries are "incompatible" on other units.
