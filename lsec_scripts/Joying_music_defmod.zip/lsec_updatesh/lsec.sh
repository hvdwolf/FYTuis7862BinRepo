#!/system/bin/sh
#

rm -rf /data/dalvik-cache/profiles/com.syu.music
rm -rf /oem/app/190043001_com.syu.music
rm -rf /oem/app/190040001_com.syu.music
rm -rf /oem/app/190001001_com.syu.music
mkdir -p /oem/app/190043001_com.syu.music
cp -rf  /storage/sdcard1/190043001_com.syu.music.apk /oem/app/190043001_com.syu.music/
chmod 0755 /oem/app/190043001_com.syu.music
chown -R 0.0 /oem/app/190043001_com.syu.music/190043001_com.syu.music.apk
chmod 0644 /oem/app/190043001_com.syu.music/190043001_com.syu.music.apk

