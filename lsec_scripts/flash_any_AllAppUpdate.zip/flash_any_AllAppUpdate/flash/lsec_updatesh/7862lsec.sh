#!/system/bin/sh

# Harry van der Wolf, V1.0, 27-05-2023
# flash script for uis7862, uis8581


cp /storage/sdcard1/myconfiguration/config.txt /oem/app
cp /storage/sdcard1/myconfiguration/fyt.prop /oem/app

chmod 644 /oem/app/config.txt
chmod 644 /oem/app/fyt.prop
