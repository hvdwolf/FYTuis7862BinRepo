## What do these scripts do and how to use them ##

These scripts are for both the uis7982 (ums512) and for the UIS8581a (sc9863a).
The AllAppUpdate.bin, that contains the FYT application layer, is for both CPUs the same.
The scripts make a copy of your current config and uses that to flash your unit using that config of your unit.

## Some information to start with ##
FYT units do have an MCU and based on the type of manufacturer you can have a different MCU firmware. This is different from the normal downloadable firmware.
The Android layer is universal on FYTs but works slighly different for different MCUs.
How this Android layer should act on the underlaying MCU is determined by a property
called "ro.build.fytmanufacturer" which can have several values. 
A second and third property are the:
 - sys.fyt.bluetooth_type property which is normally 0 or 1, but on the new M6Pro/M6Plus models anything up to 7 
 - ro.sf.swrotation. This property defines the screen orientation and is in 95% of the cases 90 (degrees), for Joyings often 270 and for Tesla screens (0 or 180).
These properties are in the fyt.prop file and in the config.txt file. These files are copied from your unit onto the usb-stick by the pre-flash script. 

## Important ##
BEFORE YOU FLASH ANYTHING TO YOUR UNIT, YOU FIRST NEED TO RUN THE "PRE-FLASH" SCRIPT !!

## Steps to perform ##
1. Take a clean FAT32 formatted USB-stick (or a (micro-)SD-card in some USB reader/writer).
2. Copy the contents inside the "pre-flash" folder onto the USB-stick (not the pre-flash folder with contents, but the contents inside the pre-flash folder).
3. Insert it into your unit, let it reboot and go into recovery mode, and wait until the green message tells you that you can remove it again.
4. Delete the "lsec_updatesh" folder including contents on your USB-stick !
5. Make sure to keep the "myconfiguration" folder and check its contents: It must contain a config.txt and a fyt.prop. If correct: copy this myconfiguration also to a save place. You nerver know. If the folder does not contain those files or one of them, then don't continue but ask in the forum.
6. Copy the AllAppUpdate.bin that you found somewhere onto the USB-stick.
7. The 6315_1.zip or 6316_1.zip?
  7a. UIS7862: If you want to flash the kernel as well, copy the 6315_1.zip onto the USB-stick.
  7b. UIS8581a: If you want to flash the kernel as well, copy the 6316_1.zip onto the USB-stick.
8. Now copy the contents of the "flash" folder onto the USB-stick.
9. Check your "lsec_updatesh" folder. Do you now also have a "lsec_updatesh (1)" folder, or inside the "lsec_updatesh" folder something like a "7862 (1).sh"? It means that you did not delete the  sec_updatesh folder on the USB-stick. Redo step 4.
10. Copy (not move) the config.txt inside the "myconfiguration" folder into the root of the uSB-stick.
11. You can now flash your unit using this USB-stick.

## Remarks ##
- If you are thinking of using this in combination with @mariodantas' kernel, you need to know what you do. Mario's kernel comes with its own scripts and fmc app.
Of course you can combine this if you know what you do, but do not simply copy everything on top of each other on this USB-stick. Please keep it separate.
- You can also combine it with PeaceOS, but also in this case @LLIyT_HuK's version comes with it's own scripts. So know what you do.
- Most newer firmwares nowadays come with an lsec script and a fyt_build.prop. This fyt_build.prop comes with a fake property to set Android to 11 or 12. I refuse to go with that absolutely incorrect and despicable behavior and I will not copy it.

