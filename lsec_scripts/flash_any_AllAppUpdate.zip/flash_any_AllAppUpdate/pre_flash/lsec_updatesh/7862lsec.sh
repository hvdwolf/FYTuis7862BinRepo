#!/system/bin/sh

# Harry van der Wolf, V1.0, 27-05-2023
# pre-flash script for uis7862, uis8581a

rm -rf /storage/sdcard1/myconfiguration
mkdir -p /storage/sdcard1/myconfiguration

cp /oem/app/config.txt /storage/sdcard1/myconfiguration
cp /oem/app/fyt.prop /storage/sdcard1/myconfiguration
