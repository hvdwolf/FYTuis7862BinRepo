#!/system/bin/sh
#

# Updating config.txt
sed  "4 a ro.build.go_lasttop=false" /oem/app/config.txt
