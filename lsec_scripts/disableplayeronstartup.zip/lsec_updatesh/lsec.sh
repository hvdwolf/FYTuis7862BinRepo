#!/system/bin/sh
#

# Updating config.txt
sed -i "4i ro.build.go_lasttop=false" /oem/app/config.txt