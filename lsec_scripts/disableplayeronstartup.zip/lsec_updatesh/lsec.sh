#!/system/bin/sh
#

sed -i "$a ro.build.go_lasttop=false" /oem/app/config.txt