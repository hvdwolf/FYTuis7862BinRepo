#!/system/bin/sh

# Harry van der Wolf, V1.0, 03-01-2022
# Backup script for uis7862, uis8518 and sc9853i

rm -rf /storage/sdcard1/BACKUP
mkdir -p /storage/sdcard1/BACKUP

echo "twipe_all" > /storage/sdcard1/BACKUP/updatecfg.txt
cp /storage/sdcard1/lsec6315update /storage/sdcard1/BACKUP
cp /oem/app/config.txt /storage/sdcard1/BACKUP

/storage/sdcard1/7zzs a -r -tzip -mx=0 -p048a02243bb74474b25233bda3cd02f8 /storage/sdcard1/BACKUP/AllAppUpdate.bin /oem/*


##############################################################################
# You will now find on your usb-stick inside the folder BACKUP
# four files:
#    AllAppUpdate.bin
#    config.txt
#    updatecfg.txt
#    lsec6315update
#
# If you copy these four files with a 6315_1.zip
# to a clean USB-disk, you can always restore
# your uis7862 (ums512) unit.
