#!/system/bin/sh

# Harry van der Wolf, V1.0, 14-01-2022
# Backup script for uis7862, uis8518 and sc9853i

rm -rf /storage/sdcard1/BACKUP
mkdir -p /storage/sdcard1/BACKUP
mkdir -p /storage/sdcard1/BACKUP/Allapp


echo "twipe_all" > /storage/sdcard1/BACKUP/updatecfg.txt
cp /storage/sdcard1/lsec6521update /storage/sdcard1/BACKUP
cp /storage/sdcard1/ApkPack.exe /storage/sdcard1/BACKUP
cp /oem/app/config.txt /storage/sdcard1/BACKUP
cp /oem/Ver /storage/sdcard1/BACKUP/Allapp/Ver 
cp -r /oem/app /storage/sdcard1/BACKUP/Allapp
cp -r /oem/priv-app /storage/sdcard1/BACKUP/Allapp
cp -r /oem/vital-app /storage/sdcard1/BACKUP/Allapp

##############################################################################
# Inside the folder BACKUP you will find
#    ApkPack.exe
#    Allapp (folder)
#    config.txt
#    updatecfg.txt
#    lsec6251update
#
# You need ApkPack.exe to create an Allapp.pkg from
# the folder Allapp. ApkPack.exe is bundled with
# this backup and is meant for Windows, but with
# runs with wine also on Linux and MacOS.
# If you copy the three files lsec6521update, config.txt,
# updatecfg.txt plus the created Allapp.pkg,
# together with a 6251_1.zip to a clean USB-disk,
# you can always restore your sc9853i unit.

