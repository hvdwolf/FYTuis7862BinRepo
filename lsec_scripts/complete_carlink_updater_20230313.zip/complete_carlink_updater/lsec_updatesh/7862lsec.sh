#!/system/bin/sh
# This will update the carlink app including necessary libraries
rm -rf /data/dalvik-cache/profiles/com.syu.carlink*
rm -rf /data/dalvik-cache/arm64/*com.syu.carlink*
rm -rf /oem/app/190000*_com.syu.carlink
cp -r /storage/sdcard1/APK/* /oem/app/

chown -R 0.0 /oem/app/190000000_com.syu.carlink
chmod 755 /oem/app/190000000_com.syu.carlink
chmod 644 /oem/app/190000000_com.syu.carlink/190000000_com.syu.carlink.apk

##################################
#    complete Carlink updater    #
##################################
#   wait at least (3) seconds    #
#   after the green "counting"   #
#   message before you remove    #
#   the USB stick                #
##################################
