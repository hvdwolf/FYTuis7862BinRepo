#!/system/bin/sh
#

sed -i '/ro\.build\.go_lasttop=false/d' /oem/app/config.txt
