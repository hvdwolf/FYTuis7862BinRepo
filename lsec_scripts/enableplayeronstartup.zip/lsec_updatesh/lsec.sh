#!/system/bin/sh
#

# Re-enabling the autostart of the mediaplayer on startup
sed -i '/ro\.build\.go_lasttop=false/d' /oem/app/config.txt
