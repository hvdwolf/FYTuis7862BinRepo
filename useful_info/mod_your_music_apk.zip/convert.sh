#!/bin/bash

# This script uses unzip & zip, and Imagemagick convert

# It takes the original apk and unzips this into a folder unzipped
# It then does modifications on the png files (reduces the brighness) and copies them into a new folder res
# It then copies the modified png files back to their original folder 
# Then it copies my couple of modified pngs and xml layout files back
# Then it zips it into a new modified apk


# Change BASE folder to wehere you unzipped the original apk and the script
BASE="/home/harryvanderwolf/128GB/FYT_9863a_7862/Joying_com.syu.music/org_50procentdarker"

cd $BASE

printf "\nClean up old stuff\n\n"
rm -rf $BASE/res
rm -rf $BASE/unzipped
rm -rf $BASE/190043001_com.syu.music.apk

mkdir -p $BASE/res $BASE/unzipped
cd $BASE/unzipped
echo "unzip the original apk\n\n"
unzip ../original_190043001_com.syu.music.apk
cd res
for i in drawable-*
do
    cd  $i
    printf "\n\nWorking on $i"
    mkdir -p $BASE/res/$i
    for img in *.png
    do
        convert -brightness-contrast -50 $img $BASE/res/$i/$img
    done
    cd $BASE/unzipped/res
done

printf "\n\nCopy my album default pngs and xml modifications in\n\n"
cd $BASE
cp -r  $BASE/my_res/* $BASE/unzipped/res/

printf "\n\nRecreate modded apk\n\n"
cd $BASE
cp -r $BASE/res/* $BASE/unzipped/res/
cd $BASE/unzipped
zip -r ../190043001_com.syu.music.apk *

printf "\n\nDONE!\n\n"
