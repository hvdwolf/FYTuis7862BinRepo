#!/system/bin/sh
#

rm -rf /data/dalvik-cache/profiles/com.syu.ms
rm -rf /oem/app/190000000_com.syu.ms
mkdir -p /oem/app/190000000_com.syu.ms
cp -rf  /storage/sdcard1/190000000_com.syu.ms.apk /oem/app/190000000_com.syu.ms/
chmod 0755 /oem/app/190000000_com.syu.ms
chown -R 0.0 /oem/app/190000000_com.syu.ms/190000000_com.syu.ms.apk
chmod 0644 /oem/app/190000000_com.syu.ms/190000000_com.syu.ms.apk
